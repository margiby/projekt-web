#!/bin/bash
## Author: @skazmin
## This script generates a CHANGELOG.md file or updates it if it is present.
## The versions come from git tags following the pattern "v*".
## The latest chagnes which do not have a version number yet appear udner the version "HEAD".
## The CHANGELOG.md can be modifed once a newer version is the latest one or there are some chnagens in HEAD.
## Manual changes to older versions will be kept.

changelog=CHANGELOG.md
branch="$1" ## name of the branch, may be useful later

## get all tags reachable from brach
mapfile -t tags < <(git tag --merged "$branch" --list 'v*' --sort=-version:refname v*)
## get the coresponding tag dates
mapfile -t tag_dates < <(git tag --merged "$branch" --list 'v*' --sort=-version:refname v* --format="%(taggerdate:raw)" | awk '{ t=strftime("%Y-%m-%d ",$i); gsub(" ", "", t); printf "%s\n", t}')

version_print (){ echo -e "$1" | awk '{gsub(/v/, "")}1' ;}

version_regex () { echo -e "$1" | awk '{gsub(/v/, "")}; {gsub(/\./, "\\.")}1' ;}

version_heading (){ echo -e "## Version $(version_print "$1") ($2)" ;}

latest_changes="$(git log --no-merges --pretty=format:'- %s' "${tags[0]}"..HEAD)"
if [[ $latest_changes != "" ]]; then
  echo "Add HEAD to tags array in order to preprint non-versioned changes"
  tags=("HEAD" "${tags[@]}")
  tag_dates=("$(date +%F)" "${tag_dates[@]}")
fi

# echo -e "${tags[@]}"

Ntags=${#tags[@]}

changes_string ()
{
  last_ind=$1
  if [[ $last_ind -ge $Ntags ]]; then
    last_ind="$((Ntags))"
  fi

  first_ind="$(( $1 - $2 ))"
  if [[ $first_ind -ge $Ntags ]]; then
    first_ind="$((Ntags))"
  fi

  output=""
  for (( i=last_ind; i < first_ind; i++ ))
  do
    output+="$(version_heading "${tags[$i]}" "${tag_dates[$i]}")"
    output+="\n\n"
    if [[ $i -ne $Ntags-1 ]]; then
      first_tag="${tags[$i+1]}.."
    else
      first_tag=""
    fi
    issue_text="$(git log --no-merges --pretty=format:'- %s' "${first_tag}${tags[$i]}")"
    issue_text="$(echo -e "$issue_text" | sed '/^\- CICD:/d')" ## remove commits starting with CICD:
    issue_text="$(echo -e "$issue_text" | sed '/^\- \[CICD\]/d')" ## remove commits starting with [CICD]
    output+="$issue_text"

    if [[ $i -ne $first_ind-1 ]]; then
      output+="\n\n"
    fi
  done

  echo -e "$output"
}

if [ -f "$changelog" ]; then
  echo "$changelog exists."

  ## get the last version number (not HEAD) in changelog
  last_version_in_changelog=$(sed -n "s/^## Version \([^H][0-9\.a-zA-Z\-]*\) .*/\1/gp" "$changelog" | head -n1)
  last_version_tag_index=-1

  ## get the index of the latest version in the tags array
  echo "${!tags[@]}"
  for i in "${!tags[@]}"; do
    if [[ "${tags[$i]}" = "v${last_version_in_changelog}" ]]; then
      last_version_tag_index=$i
      break
    fi
  done

  prefix_part="$(sed -n "/## Version/!p;//q" "$changelog")"
  postfix_part="$(sed -e "/## Version $(version_regex "${tags[$last_version_tag_index]}")/,\$b" -e "d" "$changelog")"

  if [[ $last_version_tag_index -ne 0 ]]; then
    echo "Write all changes after Version $last_version_in_changelog which is the latest version present in $changelog."
    echo -e "$prefix_part" > $changelog
    echo -e "\n$(changes_string 0 "-$last_version_tag_index")" >> $changelog
    echo -e "\n$postfix_part" >> $changelog
  else
    echo "Version $last_version_in_changelog is already present in $changelog. Do not update anything."
  fi
else
  echo "$changelog does not exist. Generate a new one."
  echo -e "# Changelog" > $changelog
  echo -e "\n$(changes_string 0 -9999)" >> $changelog
fi
