#!/bin/bash
if [[ "$1" == "" ]]; then
  LARGER_THAN_PORT=10000
else
  LARGER_THAN_PORT=$1
fi

for((port=$((LARGER_THAN_PORT + 1));port<15000;port++)); do
  if [[ "$(lsof -i:"${port}")" == "" ]]; then
    echo "${port}"
    break
  fi
done
exit 0