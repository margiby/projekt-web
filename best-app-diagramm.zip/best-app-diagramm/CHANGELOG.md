# Changelog

## Version 0.6.0 (2025-05-27)

- [Add] Footer

## Version 0.5.0 (2025-05-19)

- Routing Added

## Version 0.4.0 (2025-05-13)

- Add localization

## Version 0.3.0 (2025-05-12)

- [add] header

## Version 0.2.0 (2025-05-09)

- [add] cicd
- [add] cicd
- Create projekt
- Initial commit
