export { default as InteractiveDiagram } from './InteractiveDiagram/index'; 
export { default as HomePage } from './HomePage'; 
export { default as ApiPage } from './ApiPage';   
export { default as UploadPage } from './UploadPage';