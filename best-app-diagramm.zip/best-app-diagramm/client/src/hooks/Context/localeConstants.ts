export const DE: string = "de";
export const EN: string = "en";