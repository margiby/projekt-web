export { de, en } from "./messages"; 
export type { LanguageObj, LanguageData } from "./messages";